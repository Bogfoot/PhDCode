def set_handles(point):
    point.handle_left_type = "FREE"
    point.handle_right_type = "FREE"
