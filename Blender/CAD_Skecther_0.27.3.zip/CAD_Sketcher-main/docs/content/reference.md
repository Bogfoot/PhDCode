::: CAD_Sketcher.model.types.SketcherProps
    <!-- selection:
      members: true -->
    rendering:
      show_root_heading: true

::: CAD_Sketcher.model.types.SlvsEntities
    <!-- selection:
      members: true -->
    rendering:
      show_root_heading: true

::: CAD_Sketcher.model.types.SlvsConstraints
    <!-- selection:
      members: true -->
    rendering:
      show_root_heading: true
