blender --addons CAD_Sketcher --python ./testing/__init__.py -- --log_level=INFO
