CURVE_RESOLUTION = 64
ENTITY_PROP_NAMES = ("entity1", "entity2", "entity3", "entity4")
