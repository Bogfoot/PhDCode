def check_surface(srad,erad):
    if srad < erad:
        return False
    else:
        return True